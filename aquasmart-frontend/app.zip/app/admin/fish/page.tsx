"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { API_BASE_URL } from "@/lib/api";

type AdminFishItem = {
  id: number;
  name: string;
  slug: string;
  short_description?: string | null;
  type?: string | null;
  category?: string | null;
  habitat?: string | null;
  identify_text?: string | null;
  average_lifespan?: string | null;
  adult_size?: string | null;
  cover_image_url?: string | null;
  is_active?: boolean;
  origin?: string | null;
};

export default function AdminFishPage() {
  const [fishList, setFishList] = useState<AdminFishItem[]>([]);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [category, setCategory] = useState("");
  const [fishType, setFishType] = useState("");

  const [isLoading, setIsLoading] = useState(true);
  const [isMutating, setIsMutating] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const activeCount = useMemo(
    () => fishList.filter((fish) => fish.is_active).length,
    [fishList]
  );

  const inactiveCount = useMemo(
    () => fishList.filter((fish) => !fish.is_active).length,
    [fishList]
  );

  async function loadFish() {
    try {
      setIsLoading(true);
      setErrorMessage("");

      const params = new URLSearchParams();

      if (search.trim()) params.set("q", search.trim());
      if (status) params.set("status", status);
      if (category.trim()) params.set("category", category.trim());
      if (fishType.trim()) params.set("fish_type", fishType.trim());

      const query = params.toString();
      const url = `${API_BASE_URL}/admin/fish${query ? `?${query}` : ""}`;

      const response = await fetch(url, {
        cache: "no-store",
      });

      if (!response.ok) {
        const text = await response.text();
        throw new Error(text || "Failed to load admin fish list");
      }

      const json = await response.json();
      setFishList(json.data || []);
    } catch (error) {
      console.error("Admin fish load error:", error);
      setErrorMessage(
        error instanceof Error
          ? error.message
          : "Failed to load fish management data."
      );
      setFishList([]);
    } finally {
      setIsLoading(false);
    }
  }

  async function toggleStatus(fishId: number) {
    try {
      setIsMutating(true);
      setErrorMessage("");

      const response = await fetch(
        `${API_BASE_URL}/admin/fish/${fishId}/status`,
        {
          method: "PATCH",
        }
      );

      if (!response.ok) {
        const text = await response.text();
        throw new Error(text || "Failed to update fish status");
      }

      await loadFish();
    } catch (error) {
      console.error("Toggle status error:", error);
      setErrorMessage(
        error instanceof Error ? error.message : "Failed to update fish status."
      );
    } finally {
      setIsMutating(false);
    }
  }

  async function deleteFish(fishId: number, fishName: string) {
    const confirmed = window.confirm(
      `Delete "${fishName}"? This action cannot be undone.`
    );

    if (!confirmed) return;

    try {
      setIsMutating(true);
      setErrorMessage("");

      const response = await fetch(`${API_BASE_URL}/admin/fish/${fishId}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        const text = await response.text();
        throw new Error(text || "Failed to delete fish");
      }

      await loadFish();
    } catch (error) {
      console.error("Delete fish error:", error);
      setErrorMessage(
        error instanceof Error ? error.message : "Failed to delete fish."
      );
    } finally {
      setIsMutating(false);
    }
  }

  function clearFilters() {
    setSearch("");
    setStatus("");
    setCategory("");
    setFishType("");
  }

  useEffect(() => {
    loadFish();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <main className="min-h-screen bg-slate-50 px-4 py-8 pb-24">
      <div className="mx-auto max-w-6xl">
        <section className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="text-sm font-semibold text-blue-600">Admin</p>
              <h1 className="mt-2 text-3xl font-bold text-slate-900">
                Fish Management
              </h1>
              <p className="mt-2 text-sm leading-6 text-slate-500">
                Manage fish data, filters, images, and publish status.
              </p>
            </div>

            <Link
              href="/admin/fish/new"
              className="inline-flex items-center justify-center rounded-2xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700"
            >
              Add Fish
            </Link>
          </div>
        </section>

        <section className="mt-5 rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Search
              </label>
              <input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search by name or slug"
                className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Status
              </label>
              <select
                value={status}
                onChange={(event) => setStatus(event.target.value)}
                className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100"
              >
                <option value="">All</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Category
              </label>
              <input
                value={category}
                onChange={(event) => setCategory(event.target.value)}
                placeholder="e.g. Farmed Fish"
                className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Type
              </label>
              <input
                value={fishType}
                onChange={(event) => setFishType(event.target.value)}
                placeholder="e.g. Freshwater"
                className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100"
              />
            </div>
          </div>

          <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm text-slate-500">
              {fishList.length} fish found · {activeCount} active ·{" "}
              {inactiveCount} inactive
            </p>

            <div className="flex gap-3">
              <button
                type="button"
                onClick={loadFish}
                disabled={isLoading || isMutating}
                className="rounded-2xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:bg-slate-300"
              >
                {isLoading ? "Loading..." : "Refresh"}
              </button>

              <button
                type="button"
                onClick={clearFilters}
                disabled={isLoading || isMutating}
                className="rounded-2xl bg-white px-5 py-3 text-sm font-semibold text-slate-700 shadow-sm ring-1 ring-slate-200 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-60"
              >
                Clear Filters
              </button>
            </div>
          </div>

          {errorMessage ? (
            <div className="mt-5 rounded-2xl bg-red-50 px-4 py-3 text-sm text-red-700">
              {errorMessage}
            </div>
          ) : null}
        </section>

        {isLoading ? (
          <section className="mt-5 rounded-3xl bg-white p-6 text-center shadow-sm ring-1 ring-slate-200">
            <p className="text-sm font-medium text-slate-600">
              Loading fish management data...
            </p>
          </section>
        ) : null}

        {!isLoading && fishList.length === 0 ? (
          <section className="mt-5 rounded-3xl bg-white p-8 text-center shadow-sm ring-1 ring-slate-200">
            <p className="text-sm font-medium text-slate-600">No fish found.</p>
          </section>
        ) : null}

        {!isLoading && fishList.length > 0 ? (
          <section className="mt-5 overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-slate-200">
            <div className="hidden overflow-x-auto md:block">
              <table className="w-full min-w-[900px] text-left text-sm">
                <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                  <tr>
                    <th className="px-5 py-4">Fish</th>
                    <th className="px-5 py-4">Category</th>
                    <th className="px-5 py-4">Type</th>
                    <th className="px-5 py-4">Status</th>
                    <th className="px-5 py-4 text-right">Actions</th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100">
                  {fishList.map((fish) => (
                    <tr key={fish.id} className="align-middle">
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-3">
                          <div className="relative h-14 w-14 overflow-hidden rounded-2xl bg-slate-100">
                            {fish.cover_image_url ? (
                              <Image
                                src={fish.cover_image_url}
                                alt={fish.name}
                                fill
                                className="object-cover"
                                unoptimized
                              />
                            ) : (
                              <div className="flex h-full items-center justify-center">
                                🐟
                              </div>
                            )}
                          </div>

                          <div>
                            <p className="font-bold text-slate-900">
                              {fish.name}
                            </p>
                            <p className="mt-1 text-xs text-slate-500">
                              /{fish.slug} · ID {fish.id}
                            </p>
                          </div>
                        </div>
                      </td>

                      <td className="px-5 py-4 text-slate-600">
                        {fish.category || "-"}
                      </td>

                      <td className="px-5 py-4 text-slate-600">
                        {fish.type || "-"}
                      </td>

                      <td className="px-5 py-4">
                        <span
                          className={
                            fish.is_active
                              ? "rounded-full bg-green-50 px-3 py-1 text-xs font-semibold text-green-700"
                              : "rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600"
                          }
                        >
                          {fish.is_active ? "Active" : "Inactive"}
                        </span>
                      </td>

                      <td className="px-5 py-4">
                        <div className="flex justify-end gap-2">
                          <Link
                            href={`/fish/${fish.id}`}
                            className="rounded-xl bg-white px-3 py-2 text-xs font-semibold text-slate-700 shadow-sm ring-1 ring-slate-200 transition hover:bg-slate-50"
                          >
                            View
                          </Link>

                          <Link
                            href={`/admin/fish/${fish.id}/edit`}
                            className="rounded-xl bg-white px-3 py-2 text-xs font-semibold text-blue-700 shadow-sm ring-1 ring-blue-100 transition hover:bg-blue-50"
                          >
                            Edit
                          </Link>

                          <button
                            type="button"
                            onClick={() => toggleStatus(fish.id)}
                            disabled={isMutating}
                            className="rounded-xl bg-white px-3 py-2 text-xs font-semibold text-amber-700 shadow-sm ring-1 ring-amber-100 transition hover:bg-amber-50 disabled:opacity-60"
                          >
                            {fish.is_active ? "Unpublish" : "Publish"}
                          </button>

                          <button
                            type="button"
                            onClick={() => deleteFish(fish.id, fish.name)}
                            disabled={isMutating}
                            className="rounded-xl bg-white px-3 py-2 text-xs font-semibold text-red-700 shadow-sm ring-1 ring-red-100 transition hover:bg-red-50 disabled:opacity-60"
                          >
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="grid gap-4 p-4 md:hidden">
              {fishList.map((fish) => (
                <article
                  key={fish.id}
                  className="rounded-3xl border border-slate-100 bg-white p-4 shadow-sm"
                >
                  <div className="flex gap-3">
                    <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-2xl bg-slate-100">
                      {fish.cover_image_url ? (
                        <Image
                          src={fish.cover_image_url}
                          alt={fish.name}
                          fill
                          className="object-cover"
                          unoptimized
                        />
                      ) : (
                        <div className="flex h-full items-center justify-center">
                          🐟
                        </div>
                      )}
                    </div>

                    <div className="min-w-0">
                      <p className="font-bold text-slate-900">{fish.name}</p>
                      <p className="mt-1 text-xs text-slate-500">
                        {fish.category || "No category"}
                      </p>
                      <p className="mt-1 text-xs text-slate-500">
                        ID {fish.id} · {fish.is_active ? "Active" : "Inactive"}
                      </p>
                    </div>
                  </div>

                  <div className="mt-4 grid grid-cols-2 gap-2">
                    <Link
                      href={`/fish/${fish.id}`}
                      className="rounded-2xl bg-slate-100 px-4 py-3 text-center text-sm font-semibold text-slate-700"
                    >
                      View
                    </Link>

                    <Link
                      href={`/admin/fish/${fish.id}/edit`}
                      className="rounded-2xl bg-blue-600 px-4 py-3 text-center text-sm font-semibold text-white"
                    >
                      Edit
                    </Link>

                    <button
                      type="button"
                      onClick={() => toggleStatus(fish.id)}
                      disabled={isMutating}
                      className="rounded-2xl bg-amber-50 px-4 py-3 text-sm font-semibold text-amber-700 disabled:opacity-60"
                    >
                      {fish.is_active ? "Unpublish" : "Publish"}
                    </button>

                    <button
                      type="button"
                      onClick={() => deleteFish(fish.id, fish.name)}
                      disabled={isMutating}
                      className="rounded-2xl bg-red-50 px-4 py-3 text-sm font-semibold text-red-700 disabled:opacity-60"
                    >
                      Delete
                    </button>
                  </div>
                </article>
              ))}
            </div>
          </section>
        ) : null}
      </div>
    </main>
  );
}