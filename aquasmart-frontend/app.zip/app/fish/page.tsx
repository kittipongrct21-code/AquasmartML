"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { FishListItem, getPublicFishList } from "@/lib/api";

export default function FishCatalogPage() {
  const [fishList, setFishList] = useState<FishListItem[]>([]);
  const [filteredFish, setFilteredFish] = useState<FishListItem[]>([]);
  const [search, setSearch] = useState("");

  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    async function loadFish() {
      try {
        setIsLoading(true);
        setErrorMessage("");

        const data = await getPublicFishList();

        setFishList(data);
        setFilteredFish(data);
      } catch (error) {
        console.error("Failed to load fish list:", error);
        setErrorMessage("Failed to load fish catalog.");
      } finally {
        setIsLoading(false);
      }
    }

    loadFish();
  }, []);

  useEffect(() => {
    const keyword = search.trim().toLowerCase();

    if (!keyword) {
      setFilteredFish(fishList);
      return;
    }

    const result = fishList.filter((fish) => {
      return (
        fish.name?.toLowerCase().includes(keyword) ||
        fish.slug?.toLowerCase().includes(keyword) ||
        fish.category?.toLowerCase().includes(keyword) ||
        fish.type?.toLowerCase().includes(keyword) ||
        fish.habitat?.toLowerCase().includes(keyword)
      );
    });

    setFilteredFish(result);
  }, [search, fishList]);

  return (
    <main className="min-h-screen bg-slate-50 px-4 py-8 pb-24">
      <div className="mx-auto max-w-5xl">
        <section className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
          <p className="text-sm font-semibold text-blue-600">AquaSmart ML</p>
          <div className="mt-2 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">
                Fish Catalog
              </h1>
              <p className="mt-2 text-sm leading-6 text-slate-500">
                Explore fish species information and care details.
              </p>
            </div>

            <Link
              href="/identify"
              className="inline-flex items-center justify-center rounded-2xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700"
            >
              Identify Fish
            </Link>
          </div>

          <div className="mt-6">
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search fish by name, category, type, or habitat..."
              className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100"
            />
          </div>
        </section>

        {isLoading ? (
          <section className="mt-5 rounded-3xl bg-white p-6 text-center shadow-sm ring-1 ring-slate-200">
            <p className="text-sm font-medium text-slate-600">
              Loading fish catalog...
            </p>
          </section>
        ) : null}

        {errorMessage ? (
          <section className="mt-5 rounded-3xl bg-red-50 p-6 shadow-sm ring-1 ring-red-100">
            <p className="text-sm font-medium text-red-700">{errorMessage}</p>
          </section>
        ) : null}

        {!isLoading && !errorMessage && filteredFish.length === 0 ? (
          <section className="mt-5 rounded-3xl bg-white p-6 text-center shadow-sm ring-1 ring-slate-200">
            <p className="text-sm font-medium text-slate-600">
              No fish found.
            </p>
          </section>
        ) : null}

        {!isLoading && !errorMessage && filteredFish.length > 0 ? (
          <section className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {filteredFish.map((fish) => (
              <FishCard key={fish.id} fish={fish} />
            ))}
          </section>
        ) : null}
      </div>
    </main>
  );
}

function FishCard({ fish }: { fish: FishListItem }) {
  return (
    <article className="overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-slate-200 transition hover:-translate-y-1 hover:shadow-md">
      <div className="relative h-44 bg-slate-100">
        {fish.cover_image_url ? (
          <Image
            src={fish.cover_image_url}
            alt={fish.name}
            fill
            className="object-cover"
            unoptimized
          />
        ) : (
          <div className="flex h-full items-center justify-center text-3xl">
            🐟
          </div>
        )}
      </div>

      <div className="p-4">
        <div className="mb-3 flex items-start justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-slate-900">{fish.name}</h2>
            <p className="mt-1 text-xs font-medium text-blue-600">
              {fish.category || "Fish species"}
            </p>
          </div>
        </div>

        <p className="line-clamp-3 text-sm leading-6 text-slate-600">
          {fish.short_description || "No description available."}
        </p>

        <div className="mt-4 grid grid-cols-2 gap-2">
          <SmallInfo label="Type" value={fish.type || "-"} />
          <SmallInfo label="Habitat" value={fish.habitat || "-"} />
        </div>

        <Link
          href={`/fish/${fish.id}`}
          className="mt-4 inline-flex w-full items-center justify-center rounded-2xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700"
        >
          View Details
        </Link>
      </div>
    </article>
  );
}

function SmallInfo({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-slate-50 p-3">
      <p className="text-[11px] font-bold uppercase tracking-wide text-slate-500">
        {label}
      </p>
      <p className="mt-1 line-clamp-2 text-xs text-slate-700">{value}</p>
    </div>
  );
}