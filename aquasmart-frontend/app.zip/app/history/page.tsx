"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { supabase } from "@/lib/supabase-client";

type PredictionHistoryItem = {
  id: string;
  user_id: string;
  fish_id?: number | null;
  fish_name?: string | null;
  predicted_class: string;
  raw_predicted_class?: string | null;
  confidence_percent: number;
  prediction_type: string;
  image_url?: string | null;
  created_at: string;
};

export default function HistoryPage() {
  const [items, setItems] = useState<PredictionHistoryItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  async function loadHistory() {
    try {
      setIsLoading(true);
      setErrorMessage("");

      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser();

      if (userError) {
        throw userError;
      }

      if (!user) {
        setIsLoggedIn(false);
        setItems([]);
        return;
      }

      setIsLoggedIn(true);

      const { data, error } = await supabase
        .from("prediction_history")
        .select(
          "id, user_id, fish_id, fish_name, predicted_class, raw_predicted_class, confidence_percent, prediction_type, image_url, created_at"
        )
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (error) {
        throw error;
      }

      setItems(data || []);
    } catch (error) {
      console.error("Load history error:", error);
      setErrorMessage(
        error instanceof Error
          ? error.message
          : "Failed to load prediction history."
      );
    } finally {
      setIsLoading(false);
    }
  }

  async function deleteHistoryItem(itemId: string) {
    const confirmed = window.confirm("Delete this prediction history item?");
    if (!confirmed) return;

    try {
      setIsDeleting(true);
      setErrorMessage("");

      const { error } = await supabase
        .from("prediction_history")
        .delete()
        .eq("id", itemId);

      if (error) {
        throw error;
      }

      setItems((current) => current.filter((item) => item.id !== itemId));
    } catch (error) {
      console.error("Delete history error:", error);
      setErrorMessage(
        error instanceof Error
          ? error.message
          : "Failed to delete prediction history."
      );
    } finally {
      setIsDeleting(false);
    }
  }

  useEffect(() => {
    loadHistory();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(() => {
      loadHistory();
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  return (
    <main className="min-h-screen bg-slate-50 px-4 py-8 pb-24">
      <div className="mx-auto max-w-5xl">
        <section className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
          <p className="text-sm font-semibold text-blue-600">AquaSmart ML</p>
          <div className="mt-2 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">
                Prediction History
              </h1>
              <p className="mt-2 text-sm leading-6 text-slate-500">
                View your saved fish identification results.
              </p>
            </div>

            <Link
              href="/identify"
              className="inline-flex items-center justify-center rounded-2xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700"
            >
              Identify Fish
            </Link>
          </div>
        </section>

        {errorMessage ? (
          <section className="mt-5 rounded-3xl bg-red-50 p-5 shadow-sm ring-1 ring-red-100">
            <p className="text-sm font-medium text-red-700">{errorMessage}</p>
          </section>
        ) : null}

        {isLoading ? (
          <section className="mt-5 rounded-3xl bg-white p-8 text-center shadow-sm ring-1 ring-slate-200">
            <p className="text-sm font-semibold text-slate-600">
              Loading prediction history...
            </p>
          </section>
        ) : null}

        {!isLoading && !isLoggedIn ? (
          <section className="mt-5 rounded-3xl bg-white p-8 text-center shadow-sm ring-1 ring-slate-200">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-blue-50 text-2xl">
              🔒
            </div>
            <h2 className="text-xl font-bold text-slate-900">
              Login required
            </h2>
            <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-slate-500">
              Please login or create an account to view your prediction history.
            </p>

            <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
              <Link
                href="/auth/login?redirect=/history"
                className="inline-flex items-center justify-center rounded-2xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700"
              >
                Login
              </Link>

              <Link
                href="/auth/signup?redirect=/history"
                className="inline-flex items-center justify-center rounded-2xl bg-white px-5 py-3 text-sm font-semibold text-slate-700 shadow-sm ring-1 ring-slate-200 transition hover:bg-slate-50"
              >
                Create account
              </Link>
            </div>
          </section>
        ) : null}

        {!isLoading && isLoggedIn && items.length === 0 ? (
          <section className="mt-5 rounded-3xl bg-white p-8 text-center shadow-sm ring-1 ring-slate-200">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-slate-100 text-2xl">
              🐟
            </div>
            <h2 className="text-xl font-bold text-slate-900">
              No history yet
            </h2>
            <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-slate-500">
              Your prediction results will appear here after you identify fish
              while logged in.
            </p>

            <Link
              href="/identify"
              className="mt-6 inline-flex items-center justify-center rounded-2xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700"
            >
              Identify Fish
            </Link>
          </section>
        ) : null}

        {!isLoading && isLoggedIn && items.length > 0 ? (
          <section className="mt-5 grid gap-4 md:grid-cols-2">
            {items.map((item) => (
              <article
                key={item.id}
                className="overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-slate-200"
              >
                <div className="relative h-56 bg-slate-100">
                  {item.image_url ? (
                    <Image
                      src={item.image_url}
                      alt={item.predicted_class}
                      fill
                      className="object-contain p-4"
                      unoptimized
                    />
                  ) : (
                    <div className="flex h-full items-center justify-center text-3xl">
                      🐟
                    </div>
                  )}
                </div>

                <div className="p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wide text-blue-600">
                        Prediction
                      </p>
                      <h2 className="mt-1 text-xl font-bold text-slate-900">
                        {item.fish_name ||
                          item.raw_predicted_class ||
                          item.predicted_class}
                      </h2>
                    </div>

                    <span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700">
                      {Number(item.confidence_percent).toFixed(0)}%
                    </span>
                  </div>

                  <div className="mt-4">
                    <div className="mb-1 flex items-center justify-between text-sm">
                      <span className="font-medium text-slate-700">
                        Confidence
                      </span>
                      <span className="font-bold text-slate-900">
                        {Number(item.confidence_percent).toFixed(2)}%
                      </span>
                    </div>

                    <div className="h-3 overflow-hidden rounded-full bg-slate-200">
                      <div
                        className="h-full rounded-full bg-blue-600"
                        style={{
                          width: `${Math.max(
                            0,
                            Math.min(100, Number(item.confidence_percent))
                          )}%`,
                        }}
                      />
                    </div>
                  </div>

                  <div className="mt-4 rounded-2xl bg-slate-50 p-4">
                    <DetailRow
                      label="Prediction type"
                      value={formatPredictionType(item.prediction_type)}
                    />
                    <DetailRow
                      label="Created at"
                      value={new Date(item.created_at).toLocaleString()}
                    />
                  </div>

                  <div className="mt-4 grid grid-cols-2 gap-3">
                    {item.fish_id ? (
                      <Link
                        href={`/fish/${item.fish_id}`}
                        className="inline-flex items-center justify-center rounded-2xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700"
                      >
                        View details
                      </Link>
                    ) : (
                      <button
                        disabled
                        className="rounded-2xl bg-slate-200 px-4 py-3 text-sm font-semibold text-slate-500"
                      >
                        No detail
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => deleteHistoryItem(item.id)}
                      disabled={isDeleting}
                      className="rounded-2xl bg-red-50 px-4 py-3 text-sm font-semibold text-red-700 transition hover:bg-red-100 disabled:opacity-60"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </section>
        ) : null}
      </div>
    </main>
  );
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="mb-3 last:mb-0">
      <p className="text-xs font-bold uppercase tracking-wide text-slate-500">
        {label}
      </p>
      <p className="mt-1 text-sm leading-6 text-slate-800">{value}</p>
    </div>
  );
}

function formatPredictionType(value: string) {
  return value.replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());
}