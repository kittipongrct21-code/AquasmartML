"use client";

import { ChangeEvent, useEffect, useMemo, useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import {
  FishListItem,
  PredictionResponse,
  findFishByPrediction,
  getPublicFishList,
  predictFish,
  uploadHistoryImage,
} from "@/lib/api";
import { supabase } from "@/lib/supabase-client";

export default function IdentifyPage() {
  const router = useRouter();

  const [fishList, setFishList] = useState<FishListItem[]>([]);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState("");

  const [prediction, setPrediction] = useState<PredictionResponse | null>(null);
  const [matchedFish, setMatchedFish] = useState<FishListItem | null>(null);

  const [isLoadingFish, setIsLoadingFish] = useState(true);
  const [isPredicting, setIsPredicting] = useState(false);
  const [isSavingHistory, setIsSavingHistory] = useState(false);

  const [errorMessage, setErrorMessage] = useState("");
  const [historyMessage, setHistoryMessage] = useState("");

  const confidencePercent = useMemo(() => {
    if (!prediction) return 0;
    return Math.max(0, Math.min(100, prediction.confidence_percent || 0));
  }, [prediction]);

  const displayName = useMemo(() => {
    if (!prediction) return "";
    if (prediction.predicted_class === "unknown_fish") return "Unknown fish";
    if (prediction.predicted_class === "not_a_fish") return "Not a fish";
    return prediction.raw_predicted_class || prediction.predicted_class;
  }, [prediction]);

  useEffect(() => {
    async function loadFishList() {
      try {
        setIsLoadingFish(true);
        setErrorMessage("");

        const data = await getPublicFishList();
        setFishList(data);
      } catch (error) {
        console.error("Load fish list error:", error);
        setErrorMessage("Failed to load fish data.");
      } finally {
        setIsLoadingFish(false);
      }
    }

    loadFishList();
  }, []);

  useEffect(() => {
    return () => {
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }
    };
  }, [previewUrl]);

  function handleFileChange(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];

    setErrorMessage("");
    setHistoryMessage("");
    setPrediction(null);
    setMatchedFish(null);

    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
    }

    if (!file) {
      setSelectedFile(null);
      setPreviewUrl("");
      return;
    }

    if (!file.type.startsWith("image/")) {
      setErrorMessage("Please upload an image file.");
      setSelectedFile(null);
      setPreviewUrl("");
      return;
    }

    setSelectedFile(file);
    setPreviewUrl(URL.createObjectURL(file));
  }

  async function savePredictionHistory(
  result: PredictionResponse,
  fish: FishListItem | null,
  file: File
) {
  const {
    data: { session },
  } = await supabase.auth.getSession();

  if (!session?.user) {
    setHistoryMessage("Login to save this prediction to your history.");
    return;
  }

  try {
    setIsSavingHistory(true);

    const imageUrl = await uploadHistoryImage(session.user.id, file);

    const { error } = await supabase.from("prediction_history").insert({
      user_id: session.user.id,
      fish_id: fish?.id || null,
      fish_name: fish?.name || null,
      predicted_class: result.predicted_class,
      raw_predicted_class: result.raw_predicted_class || result.predicted_class,
      confidence_percent: result.confidence_percent,
      prediction_type: result.prediction_type,
      image_url: imageUrl,
    });

    if (error) {
      throw error;
    }

    setHistoryMessage("Saved to prediction history.");
  } catch (error) {
    console.warn("Save prediction history warning:", error);
    setHistoryMessage("Prediction completed, but history could not be saved.");
  } finally {
    setIsSavingHistory(false);
  }
}

  async function handlePredict() {
    if (!selectedFile) {
      setErrorMessage("Please select an image first.");
      return;
    }

    try {
      setErrorMessage("");
      setHistoryMessage("");
      setIsPredicting(true);

      const result = await predictFish(selectedFile);
      setPrediction(result);

      const rawName = result.raw_predicted_class || result.predicted_class;
      const fish = findFishByPrediction(fishList, rawName);
      setMatchedFish(fish);

      await savePredictionHistory(result, fish, selectedFile);
    } catch (error) {
      console.error("Prediction error:", error);
      setErrorMessage("Prediction failed. Please try again.");
    } finally {
      setIsPredicting(false);
    }
  }

  async function handleViewFullDetails() {
    if (!matchedFish) {
      setErrorMessage("Fish detail is not available for this prediction.");
      return;
    }

    const {
      data: { session },
    } = await supabase.auth.getSession();

    const targetPath = `/fish/${matchedFish.id}`;

    if (!session) {
      router.push(`/auth/signup?redirect=${encodeURIComponent(targetPath)}`);
      return;
    }

    router.push(targetPath);
  }

  return (
    <main className="min-h-screen bg-slate-50 px-4 py-6 pb-24">
      <div className="mx-auto max-w-md">
        <section className="mb-5">
          <p className="text-sm font-medium text-blue-600">AquaSmart ML</p>
          <h1 className="mt-1 text-2xl font-bold text-slate-900">
            Identify fish
          </h1>
          <p className="mt-2 text-sm leading-6 text-slate-500">
            Upload a fish image to identify the species and view basic
            information.
          </p>
        </section>

        <section className="rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-200">
          <div className="relative flex min-h-56 items-center justify-center overflow-hidden rounded-2xl bg-slate-100">
            {previewUrl ? (
              <Image
                src={previewUrl}
                alt="Selected fish"
                width={420}
                height={280}
                className="h-56 w-full object-contain"
                unoptimized
              />
            ) : (
              <div className="px-6 py-10 text-center">
                <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-blue-50 text-2xl">
                  🐟
                </div>
                <p className="text-sm font-medium text-slate-700">
                  Select fish image
                </p>
                <p className="mt-1 text-xs text-slate-500">
                  JPG, PNG, or WEBP supported
                </p>
              </div>
            )}
          </div>

          <div className="mt-4 grid gap-3">
            <label className="flex cursor-pointer items-center justify-center rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50">
              Choose image
              <input
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
              />
            </label>

            <button
              type="button"
              onClick={handlePredict}
              disabled={
                !selectedFile || isPredicting || isLoadingFish || isSavingHistory
              }
              className="rounded-2xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:bg-slate-300"
            >
              {isPredicting
                ? "Identifying..."
                : isSavingHistory
                  ? "Saving history..."
                  : "Identify now"}
            </button>
          </div>

          {errorMessage ? (
            <div className="mt-4 rounded-2xl bg-red-50 px-4 py-3 text-sm text-red-700">
              {errorMessage}
            </div>
          ) : null}

          {historyMessage ? (
            <div className="mt-4 rounded-2xl bg-blue-50 px-4 py-3 text-sm text-blue-700">
              {historyMessage}
            </div>
          ) : null}
        </section>

        {prediction ? (
          <section className="mt-5 rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-200">
            <div className="mb-4 flex items-start justify-between gap-3">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-blue-600">
                  Prediction result
                </p>
                <h2 className="mt-1 text-xl font-bold text-slate-900">
                  {displayName}
                </h2>
              </div>

              <span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700">
                {prediction.prediction_type === "known_fish"
                  ? "Known fish"
                  : "Needs review"}
              </span>
            </div>

            <div>
              <div className="mb-1 flex items-center justify-between text-sm">
                <span className="font-medium text-slate-700">Confidence</span>
                <span className="font-bold text-slate-900">
                  {confidencePercent.toFixed(0)}%
                </span>
              </div>

              <div className="h-3 overflow-hidden rounded-full bg-slate-200">
                <div
                  className="h-full rounded-full bg-blue-600 transition-all"
                  style={{ width: `${confidencePercent}%` }}
                />
              </div>
            </div>

            {matchedFish ? (
              <>
                <p className="mt-4 text-sm leading-6 text-slate-600">
                  {matchedFish.short_description ||
                    "Basic information is available for this fish species."}
                </p>

                <div className="mt-4 rounded-2xl bg-slate-50 p-4">
                  <h3 className="text-sm font-bold text-slate-900">
                    General information
                  </h3>

                  <div className="mt-3 grid grid-cols-3 gap-2">
                    <InfoBox label="Type" value={matchedFish.type || "-"} />
                    <InfoBox
                      label="Category"
                      value={matchedFish.category || "-"}
                    />
                    <InfoBox label="Habitat" value={matchedFish.habitat || "-"} />
                  </div>

                  <div className="mt-3">
                    <p className="text-xs font-bold text-slate-700">
                      How to identify
                    </p>
                    <p className="mt-1 text-xs leading-5 text-slate-500">
                      {matchedFish.identify_text || "-"}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleViewFullDetails}
                  className="mt-4 w-full rounded-2xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700"
                >
                  View full details
                </button>

                <p className="mt-3 text-center text-xs text-slate-500">
                  Full details require sign up or login.
                </p>
              </>
            ) : (
              <div className="mt-4 rounded-2xl bg-amber-50 px-4 py-3 text-sm text-amber-800">
                This prediction does not match a fish detail page yet.
              </div>
            )}
          </section>
        ) : null}
      </div>
    </main>
  );
}

function InfoBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-white p-3 text-center shadow-sm ring-1 ring-slate-100">
      <p className="text-[11px] font-bold text-slate-700">{label}</p>
      <p className="mt-1 line-clamp-2 text-[11px] text-slate-500">{value}</p>
    </div>
  );
}