import type { Metadata } from "next";
import "./globals.css";
import AppNavbar from "@/components/AppNavbar";

export const metadata: Metadata = {
  title: "AquaSmart ML",
  description: "Fish identification and fish information web application",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="bg-slate-50 text-slate-900 antialiased">
        <AppNavbar />
        {children}
      </body>
    </html>
  );
}