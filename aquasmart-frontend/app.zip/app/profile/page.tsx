"use client";

import { ChangeEvent, FormEvent, useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { supabase } from "@/lib/supabase-client";

type UserProfile = {
  id: string;
  email: string;
  avatar_url?: string | null;
  created_at?: string;
};

export default function ProfilePage() {
  const [profile, setProfile] = useState<UserProfile | null>(null);

  const [isLoading, setIsLoading] = useState(true);
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [isSigningOut, setIsSigningOut] = useState(false);

  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  async function loadProfile() {
    try {
      setIsLoading(true);
      setErrorMessage("");

      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        setProfile(null);
        return;
      }

      const { data: profileData, error: profileError } = await supabase
        .from("profiles")
        .select("id, email, avatar_url, created_at")
        .eq("id", user.id)
        .maybeSingle();

      if (profileError) {
        throw profileError;
      }

      if (!profileData) {
        const payload = {
          id: user.id,
          email: user.email || "",
          avatar_url: null,
        };

        const { data: insertedProfile, error: insertError } = await supabase
          .from("profiles")
          .insert(payload)
          .select("id, email, avatar_url, created_at")
          .single();

        if (insertError) {
          throw insertError;
        }

        setProfile({
          id: insertedProfile.id,
          email: insertedProfile.email || user.email || "",
          avatar_url: insertedProfile.avatar_url,
          created_at: insertedProfile.created_at,
        });

        return;
      }

      setProfile({
        id: profileData.id,
        email: profileData.email || user.email || "",
        avatar_url: profileData.avatar_url,
        created_at: profileData.created_at,
      });
    } catch (error) {
      console.warn("Load profile warning:", error);
      setErrorMessage(
        error instanceof Error ? error.message : "Failed to load profile."
      );
    } finally {
      setIsLoading(false);
    }
  }

  async function handleAvatarChange(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];

    if (!file || !profile) return;

    if (!file.type.startsWith("image/")) {
      setErrorMessage("Please upload an image file.");
      return;
    }

    try {
      setIsUploadingAvatar(true);
      setErrorMessage("");
      setSuccessMessage("");

      const fileExt = file.name.split(".").pop() || "jpg";
      const fileName = `${Date.now()}-${crypto.randomUUID()}.${fileExt}`;
      const filePath = `${profile.id}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from("avatars")
        .upload(filePath, file, {
          cacheControl: "3600",
          upsert: true,
        });

      if (uploadError) {
        throw uploadError;
      }

      const { data: publicUrlData } = supabase.storage
        .from("avatars")
        .getPublicUrl(filePath);

      const avatarUrl = publicUrlData.publicUrl;

      const { error: updateError } = await supabase.from("profiles").upsert({
        id: profile.id,
        email: profile.email,
        avatar_url: avatarUrl,
        updated_at: new Date().toISOString(),
      });

      if (updateError) {
        throw updateError;
      }

      setProfile({
        ...profile,
        avatar_url: avatarUrl,
      });

      setSuccessMessage("Profile image updated successfully.");
    } catch (error) {
      console.warn("Upload avatar warning:", error);
      setErrorMessage(
        error instanceof Error ? error.message : "Failed to upload profile image."
      );
    } finally {
      setIsUploadingAvatar(false);
      event.target.value = "";
    }
  }

  async function handleChangePassword(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!profile?.email) {
      setErrorMessage("Email is required to change password.");
      return;
    }

    if (newPassword.length < 6) {
      setErrorMessage("New password must be at least 6 characters.");
      return;
    }

    if (newPassword !== confirmPassword) {
      setErrorMessage("New password and confirm password do not match.");
      return;
    }

    try {
      setIsChangingPassword(true);
      setErrorMessage("");
      setSuccessMessage("");

      const { error: verifyError } = await supabase.auth.signInWithPassword({
        email: profile.email,
        password: currentPassword,
      });

      if (verifyError) {
        throw new Error("Current password is incorrect.");
      }

      const { error: updateError } = await supabase.auth.updateUser({
        password: newPassword,
      });

      if (updateError) {
        throw updateError;
      }

      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      setSuccessMessage("Password changed successfully.");
    } catch (error) {
      console.warn("Change password warning:", error);
      setErrorMessage(
        error instanceof Error ? error.message : "Failed to change password."
      );
    } finally {
      setIsChangingPassword(false);
    }
  }

  async function handleSignOut() {
    try {
      setIsSigningOut(true);
      setErrorMessage("");
      setSuccessMessage("");

      await supabase.auth.signOut();

      setProfile(null);
      window.location.href = "/auth/login";
    } catch (error) {
      console.warn("Sign out warning:", error);

      setProfile(null);
      window.location.href = "/auth/login";
    } finally {
      setIsSigningOut(false);
    }
  }

  useEffect(() => {
    loadProfile();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(() => {
      loadProfile();
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  return (
    <main className="min-h-screen bg-slate-50 px-4 py-8 pb-24">
      <div className="mx-auto max-w-4xl">
        <section className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
          <p className="text-sm font-semibold text-blue-600">AquaSmart ML</p>
          <h1 className="mt-2 text-3xl font-bold text-slate-900">Profile</h1>
          <p className="mt-2 text-sm leading-6 text-slate-500">
            Manage your profile image and password.
          </p>
        </section>

        {errorMessage ? (
          <section className="mt-5 rounded-3xl bg-red-50 p-5 shadow-sm ring-1 ring-red-100">
            <p className="text-sm font-medium text-red-700">{errorMessage}</p>
          </section>
        ) : null}

        {successMessage ? (
          <section className="mt-5 rounded-3xl bg-green-50 p-5 shadow-sm ring-1 ring-green-100">
            <p className="text-sm font-medium text-green-700">
              {successMessage}
            </p>
          </section>
        ) : null}

        {isLoading ? (
          <section className="mt-5 rounded-3xl bg-white p-8 text-center shadow-sm ring-1 ring-slate-200">
            <p className="text-sm font-semibold text-slate-700">
              Loading profile...
            </p>
          </section>
        ) : null}

        {!isLoading && !profile ? (
          <section className="mt-5 rounded-3xl bg-white p-8 text-center shadow-sm ring-1 ring-slate-200">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-slate-100 text-2xl">
              👤
            </div>

            <h2 className="text-xl font-bold text-slate-900">
              You are not logged in
            </h2>

            <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-slate-500">
              Login to manage your profile and view saved prediction history.
            </p>

            <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
              <Link
                href="/auth/login?redirect=/profile"
                className="inline-flex items-center justify-center rounded-2xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700"
              >
                Login
              </Link>

              <Link
                href="/auth/signup?redirect=/profile"
                className="inline-flex items-center justify-center rounded-2xl bg-white px-5 py-3 text-sm font-semibold text-slate-700 shadow-sm ring-1 ring-slate-200 transition hover:bg-slate-50"
              >
                Create account
              </Link>
            </div>
          </section>
        ) : null}

        {!isLoading && profile ? (
          <>
            <section className="mt-5 rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
              <div className="flex flex-col gap-6 md:flex-row md:items-center">
                <div className="relative h-28 w-28 shrink-0 overflow-hidden rounded-full bg-blue-50 ring-4 ring-blue-50">
                  {profile.avatar_url ? (
                    <Image
                      src={profile.avatar_url}
                      alt="Profile image"
                      fill
                      className="object-cover"
                      unoptimized
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center text-4xl">
                      👤
                    </div>
                  )}
                </div>

                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-blue-600">
                    Member account
                  </p>

                  <h2 className="mt-1 truncate text-2xl font-bold text-slate-900">
                    AquaSmart User
                  </h2>

                  <p className="mt-1 truncate text-sm text-slate-500">
                    {profile.email}
                  </p>

                  <div className="mt-4 flex flex-wrap gap-3">
                    <label className="inline-flex cursor-pointer items-center justify-center rounded-2xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700">
                      {isUploadingAvatar
                        ? "Uploading..."
                        : profile.avatar_url
                          ? "Change profile image"
                          : "Upload profile image"}

                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleAvatarChange}
                        disabled={isUploadingAvatar}
                        className="hidden"
                      />
                    </label>

                    <button
                      type="button"
                      onClick={handleSignOut}
                      disabled={isSigningOut}
                      className="rounded-2xl bg-red-50 px-5 py-3 text-sm font-semibold text-red-700 transition hover:bg-red-100 disabled:cursor-not-allowed disabled:opacity-60"
                    >
                      {isSigningOut ? "Signing out..." : "Sign out"}
                    </button>
                  </div>
                </div>
              </div>
            </section>

            <section className="mt-5 grid gap-4 md:grid-cols-3">
              <ProfileCard
                title="Full fish details"
                description="Access complete general, farmer, and ornamental information."
                href="/fish"
                action="Browse Fish"
              />

              <ProfileCard
                title="Identify fish"
                description="Upload a fish image and view prediction results."
                href="/identify"
                action="Identify Now"
              />

              <ProfileCard
                title="History"
                description="View your saved prediction results."
                href="/history"
                action="View History"
              />
            </section>

            <section className="mt-5 rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
              <h2 className="text-lg font-bold text-slate-900">
                Change password
              </h2>

              <p className="mt-2 text-sm leading-6 text-slate-500">
                Enter your current password and choose a new password.
              </p>

              <form onSubmit={handleChangePassword} className="mt-5 grid gap-4">
                <div>
                  <label className="mb-2 block text-sm font-medium text-slate-700">
                    Current password
                  </label>
                  <input
                    type="password"
                    value={currentPassword}
                    onChange={(event) => setCurrentPassword(event.target.value)}
                    required
                    autoComplete="current-password"
                    className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100"
                    placeholder="Current password"
                  />
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <label className="mb-2 block text-sm font-medium text-slate-700">
                      New password
                    </label>
                    <input
                      type="password"
                      value={newPassword}
                      onChange={(event) => setNewPassword(event.target.value)}
                      required
                      minLength={6}
                      autoComplete="new-password"
                      className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100"
                      placeholder="At least 6 characters"
                    />
                  </div>

                  <div>
                    <label className="mb-2 block text-sm font-medium text-slate-700">
                      Confirm new password
                    </label>
                    <input
                      type="password"
                      value={confirmPassword}
                      onChange={(event) => setConfirmPassword(event.target.value)}
                      required
                      minLength={6}
                      autoComplete="new-password"
                      className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100"
                      placeholder="Confirm new password"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isChangingPassword}
                  className="rounded-2xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:bg-slate-300 md:w-fit"
                >
                  {isChangingPassword ? "Changing password..." : "Change password"}
                </button>
              </form>
            </section>
          </>
        ) : null}
      </div>
    </main>
  );
}

function ProfileCard({
  title,
  description,
  href,
  action,
}: {
  title: string;
  description: string;
  href: string;
  action: string;
}) {
  return (
    <section className="rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
      <h3 className="text-lg font-bold text-slate-900">{title}</h3>

      <p className="mt-2 min-h-12 text-sm leading-6 text-slate-500">
        {description}
      </p>

      <Link
        href={href}
        className="mt-4 inline-flex w-full items-center justify-center rounded-2xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700"
      >
        {action}
      </Link>
    </section>
  );
}