"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { supabase } from "@/lib/supabase-client";

type NavItem = {
  href: string;
  label: string;
};

const navItems: NavItem[] = [
  { href: "/", label: "Home" },
  { href: "/fish", label: "Fish" },
  { href: "/history", label: "History" },
  { href: "/profile", label: "Profile" },
];

export default function AppNavbar() {
  const pathname = usePathname();

  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const isAdminPage = pathname.startsWith("/admin");

  useEffect(() => {
    if (isAdminPage) return;

    async function checkSession() {
      const {
        data: { session },
      } = await supabase.auth.getSession();

      setIsLoggedIn(Boolean(session));
    }

    checkSession();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setIsLoggedIn(Boolean(session));
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [isAdminPage]);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [pathname]);

  // Admin pages already have their own admin header.
  // This prevents duplicate navigation bars.
  if (isAdminPage) {
    return null;
  }

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/90 backdrop-blur">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-blue-50 text-lg">
            🐟
          </div>

          <p className="text-lg font-extrabold tracking-tight text-slate-900">
            AquaSmart<span className="text-blue-600">ML</span>
          </p>
        </Link>

        <div className="hidden items-center gap-2 md:flex">
          {navItems.map((item) => {
            const active =
              item.href === "/"
                ? pathname === "/"
                : pathname === item.href || pathname.startsWith(`${item.href}/`);

            return (
              <Link
                key={item.href}
                href={item.href}
                className={
                  active
                    ? "rounded-2xl bg-blue-50 px-4 py-2 text-sm font-semibold text-blue-700"
                    : "rounded-2xl px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100 hover:text-slate-900"
                }
              >
                {item.label}
              </Link>
            );
          })}
        </div>

        <div className="hidden items-center gap-2 md:flex">
          <Link
            href="/identify"
            className="rounded-2xl bg-blue-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700"
          >
            Identify
          </Link>

          <Link
            href={isLoggedIn ? "/profile" : "/auth/login"}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-sm shadow-sm ring-1 ring-slate-200 transition hover:bg-slate-50"
            title={isLoggedIn ? "Profile" : "Login"}
          >
            👤
          </Link>
        </div>

        <button
          type="button"
          onClick={() => setIsMenuOpen((value) => !value)}
          className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white text-xl shadow-sm ring-1 ring-slate-200 md:hidden"
          aria-label="Open menu"
        >
          ☰
        </button>
      </nav>

      {isMenuOpen ? (
        <div className="border-t border-slate-100 bg-white px-4 py-3 md:hidden">
          <div className="mx-auto grid max-w-6xl gap-2">
            {navItems.map((item) => {
              const active =
                item.href === "/"
                  ? pathname === "/"
                  : pathname === item.href || pathname.startsWith(`${item.href}/`);

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={
                    active
                      ? "rounded-2xl bg-blue-50 px-4 py-3 text-sm font-semibold text-blue-700"
                      : "rounded-2xl px-4 py-3 text-sm font-semibold text-slate-600 transition hover:bg-slate-100"
                  }
                >
                  {item.label}
                </Link>
              );
            })}

            <Link
              href="/identify"
              className="rounded-2xl bg-blue-600 px-4 py-3 text-center text-sm font-semibold text-white"
            >
              Identify Fish
            </Link>
          </div>
        </div>
      ) : null}
    </header>
  );
}