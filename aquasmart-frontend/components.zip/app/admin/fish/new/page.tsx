"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  createFish,
  type FishFarmerPayload,
  type FishGeneralPayload,
  type FishOrnamentalPayload,
} from "@/lib/api";

type CreateTab = "general" | "farmer" | "ornamental";

const EMPTY_GENERAL: FishGeneralPayload = {
  name: "",
  slug: "",
  short_description: "",
  type: "",
  category: "",
  habitat: "",
  identify_text: "",
  average_lifespan: "",
  adult_size: "",
  cover_image_url: "",
  is_active: true,
  origin: "",
};

const EMPTY_FARMER: FishFarmerPayload = {
  how_to_raise: "",
  pond_type: "",
  pond_size: "",
  population_per_pond: "",
  water_temp: "",
  ph: "",
  water_prep: "",
  recommended_food: "",
  not_recommended_food: "",
  feeding_frequency: "",
  feeding_amount: "",
  compatible_species: "",
  growth_rate: "",
  common_diseases: "",
  disease_prevention: "",
  source_type: "",
  source_size: "",
  system_type: "",
  incompatible_species: "",
  survival_rate: "",
  notes: "",
};

const EMPTY_ORNAMENTAL: FishOrnamentalPayload = {
  environment: "",
  population: "",
  water_temp: "",
  ph: "",
  preparation: "",
  recommended_food: "",
  feeding_frequency: "",
  feeding_amount: "",
  source_type: "",
  source_size: "",
  compatible_species: "",
  growth_rate: "",
  common_diseases: "",
  disease_prevention: "",
  system_type: "",
  incompatible_species: "",
  survival_rate: "",
  not_recommended_food: "",
  notes: "",
};

const GENERAL_TEXT_FIELDS: Array<{
  key: keyof FishGeneralPayload;
  label: string;
  textarea?: boolean;
}> = [
  { key: "name", label: "Fish Name" },
  { key: "slug", label: "Slug" },
  { key: "short_description", label: "Short Description", textarea: true },
  { key: "type", label: "Type" },
  { key: "category", label: "Category" },
  { key: "habitat", label: "Habitat", textarea: true },
  { key: "identify_text", label: "Identify Text", textarea: true },
  { key: "average_lifespan", label: "Average Lifespan" },
  { key: "adult_size", label: "Adult Size" },
  { key: "origin", label: "Origin" },
  { key: "cover_image_url", label: "Cover Image URL", textarea: true },
];

const FARMER_FIELDS: Array<{
  key: keyof FishFarmerPayload;
  label: string;
  textarea?: boolean;
}> = [
  { key: "how_to_raise", label: "How to Raise", textarea: true },
  { key: "pond_type", label: "Pond Type" },
  { key: "pond_size", label: "Pond Size" },
  { key: "population_per_pond", label: "Population per Pond" },
  { key: "water_temp", label: "Water Temperature" },
  { key: "ph", label: "pH" },
  { key: "water_prep", label: "Water Preparation", textarea: true },
  { key: "recommended_food", label: "Recommended Food", textarea: true },
  { key: "not_recommended_food", label: "Not Recommended Food", textarea: true },
  { key: "feeding_frequency", label: "Feeding Frequency" },
  { key: "feeding_amount", label: "Feeding Amount" },
  { key: "compatible_species", label: "Compatible Species", textarea: true },
  { key: "growth_rate", label: "Growth Rate" },
  { key: "common_diseases", label: "Common Diseases", textarea: true },
  { key: "disease_prevention", label: "Disease Prevention", textarea: true },
  { key: "source_type", label: "Source Type" },
  { key: "source_size", label: "Source Size" },
  { key: "system_type", label: "System Type" },
  { key: "incompatible_species", label: "Incompatible Species", textarea: true },
  { key: "survival_rate", label: "Survival Rate" },
  { key: "notes", label: "Notes", textarea: true },
];

const ORNAMENTAL_FIELDS: Array<{
  key: keyof FishOrnamentalPayload;
  label: string;
  textarea?: boolean;
}> = [
  { key: "environment", label: "Environment", textarea: true },
  { key: "population", label: "Population" },
  { key: "water_temp", label: "Water Temperature" },
  { key: "ph", label: "pH" },
  { key: "preparation", label: "Preparation", textarea: true },
  { key: "recommended_food", label: "Recommended Food", textarea: true },
  { key: "feeding_frequency", label: "Feeding Frequency" },
  { key: "feeding_amount", label: "Feeding Amount" },
  { key: "source_type", label: "Source Type" },
  { key: "source_size", label: "Source Size" },
  { key: "compatible_species", label: "Compatible Species", textarea: true },
  { key: "growth_rate", label: "Growth Rate" },
  { key: "common_diseases", label: "Common Diseases", textarea: true },
  { key: "disease_prevention", label: "Disease Prevention", textarea: true },
  { key: "system_type", label: "System Type" },
  { key: "incompatible_species", label: "Incompatible Species", textarea: true },
  { key: "survival_rate", label: "Survival Rate" },
  { key: "not_recommended_food", label: "Not Recommended Food", textarea: true },
  { key: "notes", label: "Notes", textarea: true },
];

export default function AdminFishNewPage() {
  const router = useRouter();

  const [tab, setTab] = useState<CreateTab>("general");

  const [general, setGeneral] = useState<FishGeneralPayload>(EMPTY_GENERAL);
  const [farmer, setFarmer] = useState<FishFarmerPayload>(EMPTY_FARMER);
  const [ornamental, setOrnamental] =
    useState<FishOrnamentalPayload>(EMPTY_ORNAMENTAL);

  const [isSaving, setIsSaving] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [statusMessage, setStatusMessage] = useState("");

  const pageTitle = useMemo(() => {
    return general.name.trim() ? `Create ${general.name.trim()}` : "Create New Fish";
  }, [general.name]);

  function updateGeneralField<K extends keyof FishGeneralPayload>(
    key: K,
    value: FishGeneralPayload[K]
  ) {
    setGeneral((prev) => ({
      ...prev,
      [key]: value,
    }));
  }

  function updateFarmerField<K extends keyof FishFarmerPayload>(
    key: K,
    value: FishFarmerPayload[K]
  ) {
    setFarmer((prev) => ({
      ...prev,
      [key]: value,
    }));
  }

  function updateOrnamentalField<K extends keyof FishOrnamentalPayload>(
    key: K,
    value: FishOrnamentalPayload[K]
  ) {
    setOrnamental((prev) => ({
      ...prev,
      [key]: value,
    }));
  }

  function resetForm() {
    setGeneral(EMPTY_GENERAL);
    setFarmer(EMPTY_FARMER);
    setOrnamental(EMPTY_ORNAMENTAL);
    setTab("general");
    setErrorMessage("");
    setStatusMessage("");
  }

  async function handleCreate() {
    if (!general.name.trim()) {
      setErrorMessage("Fish name is required.");
      setTab("general");
      return;
    }

    if (!general.slug.trim()) {
      setErrorMessage("Slug is required.");
      setTab("general");
      return;
    }

    try {
      setIsSaving(true);
      setErrorMessage("");
      setStatusMessage("");

      const response = await createFish({
        general: {
          ...general,
          name: general.name.trim(),
          slug: general.slug.trim(),
        },
        farmer,
        ornamental,
      });

      const createdId = response?.data?.fish?.id;

      setStatusMessage("Fish created successfully.");

      if (createdId) {
        router.push(`/admin/fish/${createdId}/edit`);
        router.refresh();
        return;
      }

      resetForm();
    } catch (error) {
      console.error("Failed to create fish:", error);
      setErrorMessage(
        error instanceof Error ? error.message : "Failed to create fish."
      );
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <main className="min-h-screen px-4 py-8">
      <div className="mx-auto max-w-6xl space-y-6">
        <section className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="text-sm font-semibold text-blue-600">Admin Panel</p>
              <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-slate-900">
                {pageTitle}
              </h1>
              <p className="mt-2 text-sm text-slate-600">
                Create a new fish record. After saving, continue to the edit page
                to manage gallery images and cover image.
              </p>
            </div>

            <div className="flex flex-wrap gap-3">
              <Link
                href="/admin/fish"
                className="rounded-2xl bg-slate-100 px-4 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-200"
              >
                Back to Admin List
              </Link>

              <button
                type="button"
                onClick={resetForm}
                disabled={isSaving}
                className="rounded-2xl bg-white px-4 py-3 text-sm font-semibold text-slate-700 shadow-sm ring-1 ring-slate-200 transition hover:bg-slate-50 disabled:opacity-60"
              >
                Reset Form
              </button>

              <button
                type="button"
                onClick={handleCreate}
                disabled={isSaving}
                className="rounded-2xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:bg-slate-300"
              >
                {isSaving ? "Creating..." : "Create Fish"}
              </button>
            </div>
          </div>

          <div className="mt-6 flex flex-wrap gap-2">
            <TabButton
              active={tab === "general"}
              onClick={() => setTab("general")}
              label="General"
            />
            <TabButton
              active={tab === "farmer"}
              onClick={() => setTab("farmer")}
              label="Farmer"
            />
            <TabButton
              active={tab === "ornamental"}
              onClick={() => setTab("ornamental")}
              label="Ornamental"
            />
          </div>
        </section>

        {statusMessage ? (
          <div className="rounded-2xl bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
            {statusMessage}
          </div>
        ) : null}

        {errorMessage ? (
          <div className="rounded-2xl bg-rose-50 px-4 py-3 text-sm text-rose-700">
            {errorMessage}
          </div>
        ) : null}

        {tab === "general" ? (
          <section className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <div className="grid gap-5 md:grid-cols-2">
              {GENERAL_TEXT_FIELDS.map((field) => (
                <FieldRenderer
                  key={String(field.key)}
                  label={field.label}
                  value={String(general[field.key] ?? "")}
                  textarea={field.textarea}
                  onChange={(value) =>
                    updateGeneralField(field.key, value as never)
                  }
                />
              ))}

              <div className="rounded-2xl bg-slate-50 px-4 py-4">
                <label className="flex items-center gap-3 text-sm font-semibold text-slate-700">
                  <input
                    type="checkbox"
                    checked={Boolean(general.is_active)}
                    onChange={(event) =>
                      updateGeneralField("is_active", event.target.checked)
                    }
                    className="h-4 w-4 rounded border-slate-300"
                  />
                  Publish this fish in public catalog
                </label>
              </div>
            </div>
          </section>
        ) : null}

        {tab === "farmer" ? (
          <section className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <div className="grid gap-5 md:grid-cols-2">
              {FARMER_FIELDS.map((field) => (
                <FieldRenderer
                  key={String(field.key)}
                  label={field.label}
                  value={String(farmer[field.key] ?? "")}
                  textarea={field.textarea}
                  onChange={(value) =>
                    updateFarmerField(field.key, value as never)
                  }
                />
              ))}
            </div>
          </section>
        ) : null}

        {tab === "ornamental" ? (
          <section className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <div className="grid gap-5 md:grid-cols-2">
              {ORNAMENTAL_FIELDS.map((field) => (
                <FieldRenderer
                  key={String(field.key)}
                  label={field.label}
                  value={String(ornamental[field.key] ?? "")}
                  textarea={field.textarea}
                  onChange={(value) =>
                    updateOrnamentalField(field.key, value as never)
                  }
                />
              ))}
            </div>
          </section>
        ) : null}
      </div>
    </main>
  );
}

function TabButton({
  active,
  onClick,
  label,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        active
          ? "rounded-2xl bg-blue-600 px-4 py-2 text-sm font-semibold text-white"
          : "rounded-2xl bg-slate-100 px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-200"
      }
    >
      {label}
    </button>
  );
}

function FieldRenderer({
  label,
  value,
  onChange,
  textarea,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  textarea?: boolean;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm font-semibold text-slate-700">
        {label}
      </label>

      {textarea ? (
        <textarea
          value={value}
          onChange={(event) => onChange(event.target.value)}
          rows={4}
          className="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100"
        />
      ) : (
        <input
          type="text"
          value={value}
          onChange={(event) => onChange(event.target.value)}
          className="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100"
        />
      )}
    </div>
  );
}