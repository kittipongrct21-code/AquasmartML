"use client";

import { useEffect, useMemo, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { FishDetailResponse, getPublicFishById } from "@/lib/api";
import { supabase } from "@/lib/supabase-client";

type DetailTab = "general" | "farmer" | "ornamental";

export default function FishDetailPage() {
  const params = useParams();
  const router = useRouter();

  const fishId = String(params.id);

  const [data, setData] = useState<FishDetailResponse | null>(null);
  const [activeTab, setActiveTab] = useState<DetailTab>("general");

  const [isCheckingAuth, setIsCheckingAuth] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    async function loadFishDetail() {
      setErrorMessage("");
      setIsCheckingAuth(true);
      setIsLoading(true);

      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (!session) {
        router.replace(
          `/auth/signup?redirect=${encodeURIComponent(`/fish/${fishId}`)}`
        );
        return;
      }

      setIsCheckingAuth(false);

      try {
        const detail = await getPublicFishById(fishId);
        setData(detail);
      } catch (error) {
        console.warn("Fish detail error:", error);
        setErrorMessage(
          "Fish detail could not be loaded. Please check the API connection or fish record."
        );
      } finally {
        setIsLoading(false);
      }
    }

    loadFishDetail();
  }, [fishId, router]);

  const coverImage = useMemo(() => {
    if (!data) return "";

    return (
      data.fish.cover_image_url ||
      data.images?.find((image) => image.is_cover)?.image_url ||
      data.images?.[0]?.image_url ||
      ""
    );
  }, [data]);

  if (isCheckingAuth || isLoading) {
    return (
      <main className="min-h-screen bg-slate-50 px-4 py-8 pb-24">
        <div className="mx-auto max-w-4xl">
          <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <p className="text-sm font-semibold text-blue-600">AquaSmart ML</p>
            <h1 className="mt-2 text-2xl font-bold text-slate-900">
              Loading fish detail...
            </h1>
            <p className="mt-2 text-sm text-slate-500">
              Please wait while we verify your account and load fish data.
            </p>
          </div>
        </div>
      </main>
    );
  }

  if (errorMessage || !data) {
    return (
      <main className="min-h-screen bg-slate-50 px-4 py-8 pb-24">
        <div className="mx-auto max-w-4xl">
          <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <p className="text-sm font-semibold text-blue-600">AquaSmart ML</p>
            <h1 className="mt-2 text-3xl font-bold text-slate-900">
              Fish detail unavailable
            </h1>
            <p className="mt-3 text-sm leading-6 text-red-600">
              {errorMessage || "Fish not found."}
            </p>

            <div className="mt-6 flex flex-wrap gap-3">
              <Link
                href="/identify"
                className="rounded-2xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700"
              >
                Back to Identify
              </Link>

              <Link
                href="/fish"
                className="rounded-2xl bg-white px-5 py-3 text-sm font-semibold text-slate-700 shadow-sm ring-1 ring-slate-200 transition hover:bg-slate-50"
              >
                View Fish Catalog
              </Link>
            </div>
          </div>
        </div>
      </main>
    );
  }

  const fish = data.fish;

  return (
    <main className="min-h-screen bg-slate-50 px-4 py-8 pb-24">
      <div className="mx-auto max-w-5xl">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => router.back()}
            className="rounded-2xl bg-white px-4 py-2 text-sm font-semibold text-slate-700 shadow-sm ring-1 ring-slate-200 transition hover:bg-slate-50"
          >
            Back
          </button>

          <Link
            href="/fish"
            className="rounded-2xl bg-white px-4 py-2 text-sm font-semibold text-slate-700 shadow-sm ring-1 ring-slate-200 transition hover:bg-slate-50"
          >
            Back to Directory
          </Link>
        </div>

        <section className="overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-slate-200">
          <div className="relative h-72 bg-slate-100">
            {coverImage ? (
              <Image
                src={coverImage}
                alt={fish.name}
                fill
                className="object-contain p-4"
                unoptimized
              />
            ) : (
              <div className="flex h-full items-center justify-center text-sm text-slate-400">
                No image available
              </div>
            )}
          </div>

          <div className="p-6">
            <p className="text-sm font-semibold text-blue-600">
              Full fish details
            </p>

            <div className="mt-2 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <h1 className="text-4xl font-bold text-slate-900">
                  {fish.name}
                </h1>
                <p className="mt-3 max-w-3xl text-sm leading-6 text-slate-600">
                  {fish.short_description || "No description available."}
                </p>
              </div>

              <span className="w-fit rounded-full bg-blue-50 px-4 py-2 text-xs font-bold uppercase tracking-wide text-blue-700">
                {fish.category || "Fish species"}
              </span>
            </div>
          </div>
        </section>

        <section className="mt-5 rounded-3xl bg-white p-3 shadow-sm ring-1 ring-slate-200">
          <div className="grid gap-2 md:grid-cols-3">
            <TabButton
              active={activeTab === "general"}
              title="General Information"
              description="Basic identity and habitat"
              onClick={() => setActiveTab("general")}
            />
            <TabButton
              active={activeTab === "farmer"}
              title="Farmer Guide"
              description="Culture and farming care"
              onClick={() => setActiveTab("farmer")}
            />
            <TabButton
              active={activeTab === "ornamental"}
              title="Ornamental Guide"
              description="Aquarium and hobbyist care"
              onClick={() => setActiveTab("ornamental")}
            />
          </div>
        </section>

        {activeTab === "general" ? (
          <section className="mt-5 rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <h2 className="text-xl font-bold text-slate-900">
              General Information
            </h2>
            <p className="mt-2 text-sm leading-6 text-slate-500">
              Core information for identifying and understanding this fish.
            </p>

            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              <DetailItem label="Type" value={fish.type} />
              <DetailItem label="Origin" value={fish.origin} />
              <DetailItem label="Category" value={fish.category} />
              <DetailItem label="Habitat" value={fish.habitat} />
              <DetailItem label="Average Lifespan" value={fish.average_lifespan} />
              <DetailItem label="Adult Size" value={fish.adult_size} />
            </div>

            <div className="mt-5 rounded-2xl bg-slate-50 p-4">
              <p className="text-sm font-bold text-slate-800">How to Identify</p>
              <p className="mt-2 text-sm leading-6 text-slate-600">
                {fish.identify_text || "-"}
              </p>
            </div>
          </section>
        ) : null}

        {activeTab === "farmer" ? (
          <section className="mt-5 rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <h2 className="text-xl font-bold text-slate-900">Farmer Guide</h2>
            <p className="mt-2 text-sm leading-6 text-slate-500">
              Practical aquaculture information for farmers.
            </p>

            {data.farmer_info ? (
              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                {Object.entries(data.farmer_info).map(([key, value]) => {
                  if (key === "id" || key === "fish_id") return null;

                  return (
                    <DetailItem
                      key={key}
                      label={formatLabel(key)}
                      value={String(value || "-")}
                    />
                  );
                })}
              </div>
            ) : (
              <EmptyInfo message="No farmer guide is available for this fish yet." />
            )}
          </section>
        ) : null}

        {activeTab === "ornamental" ? (
          <section className="mt-5 rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <h2 className="text-xl font-bold text-slate-900">
              Ornamental Guide
            </h2>
            <p className="mt-2 text-sm leading-6 text-slate-500">
              Aquarium and ornamental fish care information for hobbyists.
            </p>

            {data.ornamental_info ? (
              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                {Object.entries(data.ornamental_info).map(([key, value]) => {
                  if (key === "id" || key === "fish_id") return null;

                  return (
                    <DetailItem
                      key={key}
                      label={formatLabel(key)}
                      value={String(value || "-")}
                    />
                  );
                })}
              </div>
            ) : (
              <EmptyInfo message="No ornamental guide is available for this fish yet." />
            )}
          </section>
        ) : null}
      </div>
    </main>
  );
}

function TabButton({
  active,
  title,
  description,
  onClick,
}: {
  active: boolean;
  title: string;
  description: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        active
          ? "rounded-2xl bg-blue-600 p-4 text-left text-white shadow-sm"
          : "rounded-2xl bg-slate-50 p-4 text-left text-slate-700 transition hover:bg-slate-100"
      }
    >
      <p className="text-sm font-bold">{title}</p>
      <p className={active ? "mt-1 text-xs text-blue-100" : "mt-1 text-xs text-slate-500"}>
        {description}
      </p>
    </button>
  );
}

function DetailItem({
  label,
  value,
}: {
  label: string;
  value?: string | null;
}) {
  return (
    <div className="rounded-2xl bg-slate-50 p-4">
      <p className="text-xs font-bold uppercase tracking-wide text-slate-500">
        {label}
      </p>
      <p className="mt-1 text-sm leading-6 text-slate-800">{value || "-"}</p>
    </div>
  );
}

function EmptyInfo({ message }: { message: string }) {
  return (
    <div className="mt-5 rounded-2xl bg-slate-50 p-5 text-sm leading-6 text-slate-500">
      {message}
    </div>
  );
}

function formatLabel(value: string) {
  return value
    .replace(/_/g, " ")
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}