"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { getPublicFishList, type FishListItem } from "@/lib/api";

export default function FishCatalogPage() {
  const [fishList, setFishList] = useState<FishListItem[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedType, setSelectedType] = useState("all");
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    let isMounted = true;

    async function loadFishCatalog() {
      try {
        setIsLoading(true);
        setErrorMessage("");

        const data = await getPublicFishList();

        if (!isMounted) return;
        setFishList(data || []);
      } catch (error) {
        if (!isMounted) return;
        console.error("Failed to load fish catalog:", error);
        setErrorMessage(
          error instanceof Error ? error.message : "Failed to load fish catalog."
        );
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    }

    loadFishCatalog();

    return () => {
      isMounted = false;
    };
  }, []);

  const categoryOptions = useMemo(() => {
    const categories = new Set<string>();

    fishList.forEach((fish) => {
      const value = fish.category?.trim();
      if (value) categories.add(value);
    });

    return ["all", ...Array.from(categories).sort((a, b) => a.localeCompare(b))];
  }, [fishList]);

  const typeOptions = useMemo(() => {
    const types = new Set<string>();

    fishList.forEach((fish) => {
      const value = fish.type?.trim();
      if (value) types.add(value);
    });

    return ["all", ...Array.from(types).sort((a, b) => a.localeCompare(b))];
  }, [fishList]);

  const filteredFish = useMemo(() => {
    const keyword = searchTerm.trim().toLowerCase();

    return fishList.filter((fish) => {
      const matchesSearch =
        !keyword ||
        fish.name.toLowerCase().includes(keyword) ||
        (fish.slug || "").toLowerCase().includes(keyword) ||
        (fish.short_description || "").toLowerCase().includes(keyword) ||
        (fish.category || "").toLowerCase().includes(keyword) ||
        (fish.type || "").toLowerCase().includes(keyword) ||
        (fish.habitat || "").toLowerCase().includes(keyword) ||
        (fish.origin || "").toLowerCase().includes(keyword);

      const matchesCategory =
        selectedCategory === "all" || fish.category === selectedCategory;

      const matchesType =
        selectedType === "all" || fish.type === selectedType;

      return matchesSearch && matchesCategory && matchesType;
    });
  }, [fishList, searchTerm, selectedCategory, selectedType]);

  return (
    <main className="min-h-screen px-4 py-8">
      <section className="mx-auto max-w-6xl space-y-6">
        <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="text-sm font-semibold text-blue-600">Fish Catalog</p>
              <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-slate-900">
                Browse fish species
              </h1>
              <p className="mt-2 text-sm text-slate-600">
                Search fish by name, category, type, habitat, or origin.
              </p>
            </div>

            <Link
              href="/identify"
              className="rounded-2xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white transition hover:bg-blue-700"
            >
              Identify Fish
            </Link>
          </div>

          <div className="mt-6 grid gap-4 lg:grid-cols-[minmax(0,1fr)_220px_220px]">
            <div>
              <label
                htmlFor="fish-search"
                className="mb-2 block text-sm font-semibold text-slate-700"
              >
                Search
              </label>
              <input
                id="fish-search"
                type="text"
                value={searchTerm}
                onChange={(event) => setSearchTerm(event.target.value)}
                placeholder="Search fish name, category, type, habitat..."
                className="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100"
              />
            </div>

            <div>
              <label
                htmlFor="fish-category"
                className="mb-2 block text-sm font-semibold text-slate-700"
              >
                Category
              </label>
              <select
                id="fish-category"
                value={selectedCategory}
                onChange={(event) => setSelectedCategory(event.target.value)}
                className="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100"
              >
                {categoryOptions.map((option) => (
                  <option key={option} value={option}>
                    {option === "all" ? "All categories" : option}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="fish-type"
                className="mb-2 block text-sm font-semibold text-slate-700"
              >
                Type
              </label>
              <select
                id="fish-type"
                value={selectedType}
                onChange={(event) => setSelectedType(event.target.value)}
                className="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100"
              >
                {typeOptions.map((option) => (
                  <option key={option} value={option}>
                    {option === "all" ? "All types" : option}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="mt-5 flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-slate-50 px-4 py-3">
            <p className="text-sm text-slate-600">
              Showing{" "}
              <span className="font-bold text-slate-900">
                {filteredFish.length}
              </span>{" "}
              fish
            </p>

            {(searchTerm || selectedCategory !== "all" || selectedType !== "all") && (
              <button
                type="button"
                onClick={() => {
                  setSearchTerm("");
                  setSelectedCategory("all");
                  setSelectedType("all");
                }}
                className="rounded-2xl bg-white px-4 py-2 text-sm font-semibold text-slate-700 ring-1 ring-slate-200 transition hover:bg-slate-100"
              >
                Clear filters
              </button>
            )}
          </div>
        </div>

        {isLoading ? (
          <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <div className="rounded-2xl bg-slate-50 px-4 py-4 text-sm text-slate-600">
              Loading fish catalog...
            </div>
          </div>
        ) : null}

        {errorMessage ? (
          <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <div className="rounded-2xl bg-rose-50 px-4 py-4 text-sm text-rose-700">
              {errorMessage}
            </div>
          </div>
        ) : null}

        {!isLoading && !errorMessage && filteredFish.length === 0 ? (
          <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <div className="rounded-2xl bg-slate-50 px-4 py-4 text-sm text-slate-600">
              No fish matched your current filters.
            </div>

            <div className="mt-4 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => {
                  setSearchTerm("");
                  setSelectedCategory("all");
                  setSelectedType("all");
                }}
                className="rounded-2xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white transition hover:bg-blue-700"
              >
                Reset filters
              </button>

              <Link
                href="/identify"
                className="rounded-2xl bg-slate-100 px-4 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-200"
              >
                Go to Identify
              </Link>
            </div>
          </div>
        ) : null}

        {!isLoading && filteredFish.length > 0 ? (
          <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
            {filteredFish.map((fish) => (
              <FishCard key={fish.id} fish={fish} />
            ))}
          </div>
        ) : null}
      </section>
    </main>
  );
}

function FishCard({ fish }: { fish: FishListItem }) {
  return (
    <Link
      href={`/fish/${fish.id}`}
      className="group overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-slate-200 transition hover:-translate-y-1 hover:shadow-md"
    >
      <div className="flex h-56 items-center justify-center overflow-hidden bg-slate-50">
        {fish.cover_image_url ? (
          <img
            src={fish.cover_image_url}
            alt={fish.name}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-slate-100">
            <span className="text-lg font-bold text-slate-400">AS</span>
          </div>
        )}
      </div>

      <div className="p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 className="text-xl font-extrabold tracking-tight text-slate-900 transition group-hover:text-blue-700">
              {fish.name}
            </h2>

            <p className="mt-1 text-xs font-semibold uppercase tracking-wide text-slate-400">
              {fish.category || "Fish"}
            </p>
          </div>

          <span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700">
            {fish.type || "Unknown"}
          </span>
        </div>

        <p className="mt-4 line-clamp-3 text-sm leading-7 text-slate-600">
          {fish.short_description || "No description available."}
        </p>

        <div className="mt-5 grid gap-3 sm:grid-cols-2">
          <InfoPill label="Habitat" value={fish.habitat || "Not available"} />
          <InfoPill label="Origin" value={fish.origin || "Not available"} />
        </div>

        <div className="mt-5 rounded-2xl bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-700 transition group-hover:bg-blue-50 group-hover:text-blue-700">
          View details
        </div>
      </div>
    </Link>
  );
}

function InfoPill({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-slate-50 px-3 py-3">
      <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">
        {label}
      </p>
      <p className="mt-1 line-clamp-2 text-sm font-semibold text-slate-700">
        {value}
      </p>
    </div>
  );
}