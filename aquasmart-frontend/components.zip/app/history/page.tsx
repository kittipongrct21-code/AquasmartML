"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  deleteHistory,
  getPredictionHistory,
  type HistoryItem,
} from "@/lib/api";
import { supabase } from "@/lib/supabase-client";

export default function HistoryPage() {
  const [userId, setUserId] = useState<string | null>(null);
  const [historyItems, setHistoryItems] = useState<HistoryItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDeletingId, setIsDeletingId] = useState<number | null>(null);
  const [errorMessage, setErrorMessage] = useState("");
  const [statusMessage, setStatusMessage] = useState("");

  useEffect(() => {
    let isMounted = true;

    async function bootstrap() {
      try {
        setIsLoading(true);
        setErrorMessage("");
        setStatusMessage("");

        const sessionData = await supabase.auth.getSession();
        const currentUserId = sessionData.data.session?.user?.id ?? null;

        if (!isMounted) return;

        setUserId(currentUserId);

        if (!currentUserId) {
          setHistoryItems([]);
          return;
        }

        const items = await getPredictionHistory(currentUserId);

        if (!isMounted) return;
        setHistoryItems(items || []);
      } catch (error) {
        if (!isMounted) return;
        console.error("Failed to load history:", error);
        setErrorMessage(
          error instanceof Error ? error.message : "Failed to load history."
        );
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    }

    bootstrap();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (_event, session) => {
      const nextUserId = session?.user?.id ?? null;
      setUserId(nextUserId);

      if (!nextUserId) {
        setHistoryItems([]);
        return;
      }

      try {
        setIsLoading(true);
        const items = await getPredictionHistory(nextUserId);
        setHistoryItems(items || []);
      } catch (error) {
        console.error("Failed to refresh history:", error);
        setErrorMessage(
          error instanceof Error ? error.message : "Failed to refresh history."
        );
      } finally {
        setIsLoading(false);
      }
    });

    return () => {
      isMounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const sortedItems = useMemo(() => {
    return [...historyItems].sort((a, b) => {
      const left = a.created_at ? new Date(a.created_at).getTime() : 0;
      const right = b.created_at ? new Date(b.created_at).getTime() : 0;
      return right - left;
    });
  }, [historyItems]);

  async function handleDelete(historyId: number) {
    try {
      setIsDeletingId(historyId);
      setErrorMessage("");
      setStatusMessage("");

      await deleteHistory(historyId);
      setHistoryItems((prev) => prev.filter((item) => item.id !== historyId));
      setStatusMessage("History item deleted successfully.");
    } catch (error) {
      console.error("Failed to delete history:", error);
      setErrorMessage(
        error instanceof Error ? error.message : "Failed to delete history."
      );
    } finally {
      setIsDeletingId(null);
    }
  }

  if (isLoading) {
    return (
      <main className="min-h-screen px-4 py-8">
        <section className="mx-auto max-w-5xl rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
          <p className="text-sm text-slate-500">Loading prediction history...</p>
        </section>
      </main>
    );
  }

  if (!userId) {
    return (
      <main className="min-h-screen px-4 py-8">
        <section className="mx-auto max-w-5xl space-y-6">
          <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <p className="text-sm font-semibold text-blue-600">History</p>
            <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-slate-900">
              Prediction history
            </h1>
            <p className="mt-2 text-sm text-slate-600">
              Sign in first to view the fish predictions saved to your account.
            </p>
          </div>

          <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <div className="rounded-2xl bg-amber-50 px-4 py-4 text-sm text-amber-700">
              You are not signed in right now.
            </div>

            <div className="mt-4 flex flex-wrap gap-3">
              <Link
                href="/identify"
                className="rounded-2xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white transition hover:bg-blue-700"
              >
                Go to Identify
              </Link>

              <Link
                href="/fish"
                className="rounded-2xl bg-slate-100 px-4 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-200"
              >
                Browse Fish Catalog
              </Link>
            </div>
          </div>
        </section>
      </main>
    );
  }

  return (
    <main className="min-h-screen px-4 py-8">
      <section className="mx-auto max-w-5xl space-y-6">
        <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="text-sm font-semibold text-blue-600">History</p>
              <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-slate-900">
                Prediction history
              </h1>
              <p className="mt-2 text-sm text-slate-600">
                Review the fish images you identified and revisit their details.
              </p>
            </div>

            <div className="rounded-2xl bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-700">
              {sortedItems.length} item{sortedItems.length === 1 ? "" : "s"}
            </div>
          </div>
        </div>

        {statusMessage ? (
          <div className="rounded-2xl bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
            {statusMessage}
          </div>
        ) : null}

        {errorMessage ? (
          <div className="rounded-2xl bg-rose-50 px-4 py-3 text-sm text-rose-700">
            {errorMessage}
          </div>
        ) : null}

        {sortedItems.length === 0 ? (
          <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <div className="rounded-2xl bg-slate-50 px-4 py-4 text-sm text-slate-600">
              No prediction history found yet. Try identifying a fish first.
            </div>

            <div className="mt-4">
              <Link
                href="/identify"
                className="inline-flex rounded-2xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white transition hover:bg-blue-700"
              >
                Identify a fish
              </Link>
            </div>
          </div>
        ) : (
          <div className="grid gap-4">
            {sortedItems.map((item) => {
              const imageUrl =
                item.image_url ||
                item.uploaded_image_url ||
                "/fish-placeholder.png";

              const confidence =
                typeof item.confidence_percent === "number"
                  ? Math.max(0, Math.min(100, Number(item.confidence_percent)))
                  : 0;

              const predictedLabel =
                item.fish_name ||
                item.predicted_class ||
                item.raw_predicted_class ||
                "Unknown fish";

              return (
                <article
                  key={item.id}
                  className="overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-slate-200"
                >
                  <div className="grid gap-0 md:grid-cols-[180px_minmax(0,1fr)]">
                    <div className="bg-slate-50 p-4">
                      <div className="flex h-full min-h-[160px] items-center justify-center overflow-hidden rounded-2xl bg-white">
                        <img
                          src={imageUrl}
                          alt={predictedLabel}
                          className="h-full w-full object-cover"
                        />
                      </div>
                    </div>

                    <div className="p-5">
                      <div className="flex flex-wrap items-start justify-between gap-4">
                        <div>
                          <p className="text-sm font-semibold text-blue-600">
                            {item.prediction_type || "Prediction"}
                          </p>
                          <h2 className="mt-1 text-2xl font-extrabold tracking-tight text-slate-900">
                            {predictedLabel}
                          </h2>
                          <p className="mt-2 text-sm text-slate-500">
                            {formatDate(item.created_at)}
                          </p>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleDelete(item.id)}
                          disabled={isDeletingId === item.id}
                          className="rounded-2xl bg-rose-50 px-4 py-2 text-sm font-semibold text-rose-700 transition hover:bg-rose-100 disabled:cursor-not-allowed disabled:opacity-60"
                        >
                          {isDeletingId === item.id ? "Deleting..." : "Delete"}
                        </button>
                      </div>

                      <div className="mt-5">
                        <div className="mb-2 flex items-center justify-between text-sm">
                          <span className="font-semibold text-slate-700">
                            Confidence
                          </span>
                          <span className="font-bold text-blue-700">
                            {confidence ? `${confidence.toFixed(0)}%` : "--"}
                          </span>
                        </div>

                        <div className="h-3 w-full overflow-hidden rounded-full bg-slate-200">
                          <div
                            className="h-full rounded-full bg-blue-500 transition-all"
                            style={{ width: `${confidence}%` }}
                          />
                        </div>
                      </div>

                      <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                        <InfoBox
                          label="Predicted class"
                          value={item.predicted_class || "Not available"}
                        />
                        <InfoBox
                          label="Raw class"
                          value={
                            item.raw_predicted_class ||
                            item.predicted_class ||
                            "Not available"
                          }
                        />
                        <InfoBox
                          label="Fish name"
                          value={item.fish_name || "No catalog match"}
                        />
                        <InfoBox
                          label="History ID"
                          value={String(item.id)}
                        />
                      </div>

                      <div className="mt-5 flex flex-wrap gap-3">
                        {item.fish_id ? (
                          <Link
                            href={`/fish/${item.fish_id}`}
                            className="rounded-2xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white transition hover:bg-blue-700"
                          >
                            View fish detail
                          </Link>
                        ) : (
                          <div className="rounded-2xl bg-slate-100 px-4 py-3 text-sm font-semibold text-slate-600">
                            No linked fish detail
                          </div>
                        )}

                        <Link
                          href="/identify"
                          className="rounded-2xl bg-slate-100 px-4 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-200"
                        >
                          Predict another image
                        </Link>
                      </div>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>
    </main>
  );
}

function InfoBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-slate-50 px-4 py-3">
      <p className="text-xs font-bold uppercase tracking-wide text-slate-400">
        {label}
      </p>
      <p className="mt-2 text-sm font-semibold leading-7 text-slate-800">
        {value}
      </p>
    </div>
  );
}

function formatDate(value?: string | null) {
  if (!value) return "Unknown date";

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Unknown date";

  return new Intl.DateTimeFormat("en-US", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(date);
}