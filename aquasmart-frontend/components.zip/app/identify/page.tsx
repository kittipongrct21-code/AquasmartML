"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  findFishByPrediction,
  getPublicFishList,
  predictFish,
  type FishListItem,
  type PredictionResponse,
} from "@/lib/api";
import { supabase } from "@/lib/supabase-client";

export default function IdentifyPage() {
  const [fishList, setFishList] = useState<FishListItem[]>([]);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>("");
  const [result, setResult] = useState<PredictionResponse | null>(null);
  const [matchedFish, setMatchedFish] = useState<FishListItem | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [isLoadingFish, setIsLoadingFish] = useState(true);
  const [isPredicting, setIsPredicting] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [statusMessage, setStatusMessage] = useState("");

  useEffect(() => {
    let isMounted = true;

    async function bootstrap() {
      try {
        setIsLoadingFish(true);
        setErrorMessage("");

        const [fishData, sessionData] = await Promise.all([
          getPublicFishList(),
          supabase.auth.getSession(),
        ]);

        if (!isMounted) return;

        setFishList(fishData || []);
        setUserId(sessionData.data.session?.user?.id ?? null);
      } catch (error) {
        if (!isMounted) return;
        console.error("Failed to initialize identify page:", error);
        setErrorMessage(
          error instanceof Error
            ? error.message
            : "Failed to load fish data."
        );
      } finally {
        if (isMounted) {
          setIsLoadingFish(false);
        }
      }
    }

    bootstrap();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setUserId(session?.user?.id ?? null);
    });

    return () => {
      isMounted = false;
      subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (!selectedFile) {
      setPreviewUrl("");
      return;
    }

    const objectUrl = URL.createObjectURL(selectedFile);
    setPreviewUrl(objectUrl);

    return () => {
      URL.revokeObjectURL(objectUrl);
    };
  }, [selectedFile]);

  const confidenceValue = useMemo(() => {
    if (!result?.confidence_percent) return 0;
    return Math.max(0, Math.min(100, Number(result.confidence_percent)));
  }, [result]);

  function handleFileChange(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0] ?? null;

    setSelectedFile(file);
    setResult(null);
    setMatchedFish(null);
    setErrorMessage("");
    setStatusMessage("");
  }

  async function handlePredict() {
    if (!selectedFile) {
      setErrorMessage("Please choose an image first.");
      return;
    }

    try {
      setIsPredicting(true);
      setErrorMessage("");
      setStatusMessage("");

      const prediction = await predictFish(selectedFile, userId ?? undefined);
      setResult(prediction);

      const predictedName =
        prediction.raw_predicted_class || prediction.predicted_class || "";

      const matched = predictedName
        ? findFishByPrediction(fishList, predictedName)
        : null;

      setMatchedFish(matched);

      if (userId) {
        setStatusMessage("Prediction completed and saved to your history.");
      } else {
        setStatusMessage(
          "Prediction completed. Sign in if you want history to be saved automatically."
        );
      }
    } catch (error) {
      console.error("Prediction failed:", error);
      setErrorMessage(
        error instanceof Error ? error.message : "Prediction failed."
      );
      setResult(null);
      setMatchedFish(null);
    } finally {
      setIsPredicting(false);
    }
  }

  return (
    <main className="min-h-screen px-4 py-8">
      <section className="mx-auto max-w-5xl">
        <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
          <p className="text-sm font-semibold text-blue-600">AquaSmart ML</p>
          <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-slate-900">
            Identify fish
          </h1>
          <p className="mt-2 text-sm text-slate-600">
            Upload a fish image to identify the species and view basic
            information.
          </p>
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-[420px_minmax(0,1fr)]">
          <div className="rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
            <div className="rounded-3xl border border-dashed border-slate-300 bg-slate-50 p-4">
              <div className="flex min-h-[280px] items-center justify-center overflow-hidden rounded-2xl bg-white">
                {previewUrl ? (
                  <img
                    src={previewUrl}
                    alt="Selected fish preview"
                    className="h-full w-full object-contain"
                  />
                ) : (
                  <div className="px-6 text-center">
                    <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-blue-50 text-2xl font-bold text-blue-600">
                      AI
                    </div>
                    <p className="mt-4 text-base font-semibold text-slate-800">
                      Select fish image
                    </p>
                    <p className="mt-1 text-sm text-slate-500">
                      JPG, PNG, or WEBP supported
                    </p>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-4">
              <label
                htmlFor="fish-image"
                className="mb-2 block text-sm font-semibold text-slate-700"
              >
                Choose image
              </label>

              <input
                id="fish-image"
                type="file"
                accept="image/png,image/jpeg,image/webp"
                onChange={handleFileChange}
                className="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 file:mr-4 file:rounded-xl file:border-0 file:bg-blue-50 file:px-4 file:py-2 file:font-semibold file:text-blue-700 hover:file:bg-blue-100"
              />
            </div>

            <button
              type="button"
              onClick={handlePredict}
              disabled={!selectedFile || isPredicting || isLoadingFish}
              className="mt-4 w-full rounded-2xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:bg-slate-300"
            >
              {isPredicting ? "Identifying..." : "Identify now"}
            </button>

            {statusMessage ? (
              <div className="mt-4 rounded-2xl bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
                {statusMessage}
              </div>
            ) : null}

            {errorMessage ? (
              <div className="mt-4 rounded-2xl bg-rose-50 px-4 py-3 text-sm text-rose-700">
                {errorMessage}
              </div>
            ) : null}
          </div>

          <div className="space-y-6">
            <div className="rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold text-blue-600">
                    AI Result
                  </p>
                  <h2 className="mt-1 text-2xl font-extrabold tracking-tight text-slate-900">
                    {result?.predicted_class || "Waiting for prediction"}
                  </h2>
                  <p className="mt-2 text-sm text-slate-600">
                    {matchedFish?.short_description ||
                      "The result card will show the detected fish and basic information here."}
                  </p>
                </div>

                <div className="rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700">
                  AI Identified
                </div>
              </div>

              <div className="mt-5">
                <div className="mb-2 flex items-center justify-between text-sm">
                  <span className="font-semibold text-slate-700">
                    Confidence
                  </span>
                  <span className="font-bold text-blue-700">
                    {confidenceValue ? `${confidenceValue.toFixed(0)}%` : "--"}
                  </span>
                </div>

                <div className="h-3 w-full overflow-hidden rounded-full bg-slate-200">
                  <div
                    className="h-full rounded-full bg-blue-500 transition-all"
                    style={{ width: `${confidenceValue}%` }}
                  />
                </div>
              </div>

              <div className="mt-6 grid gap-3 sm:grid-cols-3">
                <InfoBox
                  label="Type"
                  value={matchedFish?.type || "Not available"}
                />
                <InfoBox
                  label="Category"
                  value={matchedFish?.category || "Not available"}
                />
                <InfoBox
                  label="Habitat"
                  value={matchedFish?.habitat || "Not available"}
                />
              </div>

              <div className="mt-6">
                {matchedFish ? (
                  userId ? (
                    <Link
                      href={`/fish/${matchedFish.id}`}
                      className="inline-flex w-full items-center justify-center rounded-2xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white transition hover:bg-blue-700 sm:w-auto"
                    >
                      View full fish details
                    </Link>
                  ) : (
                    <div className="rounded-2xl bg-amber-50 px-4 py-3 text-sm text-amber-700">
                      Sign in first to open the full fish detail page.
                    </div>
                  )
                ) : (
                  <div className="rounded-2xl bg-slate-50 px-4 py-3 text-sm text-slate-600">
                    Full details will appear when the predicted result matches a
                    fish in the catalog.
                  </div>
                )}
              </div>
            </div>

            {result ? (
              <div className="rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
                <h3 className="text-lg font-bold text-slate-900">
                  Prediction summary
                </h3>

                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <InfoBox
                    label="Predicted class"
                    value={result.predicted_class || "Not available"}
                  />
                  <InfoBox
                    label="Raw class"
                    value={
                      result.raw_predicted_class ||
                      result.predicted_class ||
                      "Not available"
                    }
                  />
                  <InfoBox
                    label="Prediction type"
                    value={result.prediction_type || "Not available"}
                  />
                  <InfoBox
                    label="Catalog match"
                    value={matchedFish?.name || "No direct match"}
                  />
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </section>
    </main>
  );
}

function InfoBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-slate-50 px-4 py-3">
      <p className="text-xs font-bold uppercase tracking-wide text-slate-400">
        {label}
      </p>
      <p className="mt-2 text-sm font-semibold text-slate-800">{value}</p>
    </div>
  );
}