"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { FishListItem, getPublicFishList } from "@/lib/api";

export default function HomePage() {
  const [fishList, setFishList] = useState<FishListItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    async function loadFish() {
      try {
        setIsLoading(true);
        setErrorMessage("");

        const data = await getPublicFishList();
        setFishList(data.slice(0, 4));
      } catch (error) {
        console.warn("Load featured fish warning:", error);
        setErrorMessage("Failed to load featured fish.");
      } finally {
        setIsLoading(false);
      }
    }

    loadFish();
  }, []);

  return (
    <main className="min-h-screen bg-slate-50 px-4 py-8 pb-24">
      <div className="mx-auto max-w-6xl">
        <section className="overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-slate-200">
          <div className="grid gap-6 p-6 md:grid-cols-[1.4fr_0.8fr] md:p-8">
            <div>
              <p className="text-sm font-semibold text-blue-600">
                AquaSmart ML
              </p>

              <h1 className="mt-3 text-4xl font-extrabold tracking-tight text-slate-900 md:text-5xl">
                Fish Search & Identification
              </h1>

              <p className="mt-4 max-w-2xl text-sm leading-7 text-slate-600 md:text-base">
                Discover fish information from the catalog and identify fish
                from images using the AI model.
              </p>

              <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                <Link
                  href="/identify"
                  className="inline-flex items-center justify-center rounded-2xl bg-blue-600 px-6 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700"
                >
                  Identify Fish
                </Link>

                <Link
                  href="/fish"
                  className="inline-flex items-center justify-center rounded-2xl bg-white px-6 py-3 text-sm font-semibold text-slate-700 shadow-sm ring-1 ring-slate-200 transition hover:bg-slate-50"
                >
                  Browse Fish Catalog
                </Link>
              </div>
            </div>

            <div className="rounded-3xl bg-blue-50 p-5">
              <div className="flex h-full min-h-56 flex-col justify-center rounded-2xl bg-white p-5 shadow-sm">
                <div className="text-4xl">🐟</div>
                <h2 className="mt-4 text-xl font-bold text-slate-900">
                  AI Fish Prediction
                </h2>
                <p className="mt-2 text-sm leading-6 text-slate-500">
                  Upload an image, get confidence score, and continue to full
                  fish details after login.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="mt-6 grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
          <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <div className="flex items-center justify-between gap-3">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">
                  Featured Fish
                </h2>
                <p className="mt-1 text-sm text-slate-500">
                  Real fish records loaded from the database.
                </p>
              </div>

              <Link
                href="/fish"
                className="text-sm font-semibold text-blue-600 hover:text-blue-700"
              >
                View all
              </Link>
            </div>

            {isLoading ? (
              <div className="mt-5 rounded-2xl bg-slate-50 p-6 text-center text-sm text-slate-500">
                Loading fish data...
              </div>
            ) : null}

            {errorMessage ? (
              <div className="mt-5 rounded-2xl bg-red-50 p-4 text-sm text-red-700">
                {errorMessage}
              </div>
            ) : null}

            {!isLoading && !errorMessage && fishList.length === 0 ? (
              <div className="mt-5 rounded-2xl bg-slate-50 p-6 text-center text-sm text-slate-500">
                No fish data found.
              </div>
            ) : null}

            {!isLoading && fishList.length > 0 ? (
              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                {fishList.map((fish) => (
                  <Link
                    key={fish.id}
                    href={`/fish/${fish.id}`}
                    className="group overflow-hidden rounded-3xl bg-slate-50 ring-1 ring-slate-100 transition hover:-translate-y-1 hover:bg-white hover:shadow-md"
                  >
                    <div className="relative h-40 bg-slate-100">
                      {fish.cover_image_url ? (
                        <Image
                          src={fish.cover_image_url}
                          alt={fish.name}
                          fill
                          className="object-cover"
                          unoptimized
                        />
                      ) : (
                        <div className="flex h-full items-center justify-center text-3xl">
                          🐟
                        </div>
                      )}
                    </div>

                    <div className="p-4">
                      <h3 className="font-bold text-slate-900 group-hover:text-blue-700">
                        {fish.name}
                      </h3>
                      <p className="mt-1 text-xs font-medium text-blue-600">
                        {fish.category || "Fish species"}
                      </p>
                      <p className="mt-2 line-clamp-2 text-sm leading-6 text-slate-500">
                        {fish.short_description || "No description available."}
                      </p>
                    </div>
                  </Link>
                ))}
              </div>
            ) : null}
          </div>

          <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <h2 className="text-2xl font-bold text-slate-900">
              Quick Actions
            </h2>

            <div className="mt-5 grid gap-3">
              <QuickAction
                href="/identify"
                title="Identify with AI"
                description="Upload a fish image and get instant prediction results."
              />

              <QuickAction
                href="/fish"
                title="Browse Fish Catalog"
                description="Explore fish species from the database."
              />

              <QuickAction
                href="/history"
                title="View History"
                description="Check your recent fish prediction activity."
              />

              <QuickAction
                href="/profile"
                title="Manage Profile"
                description="Update your profile image and account settings."
              />
            </div>
          </div>
        </section>

        <section className="mt-6 rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
          <h2 className="text-2xl font-bold text-slate-900">
            How AquaSmart ML works
          </h2>

          <div className="mt-5 grid gap-4 md:grid-cols-3">
            <StepCard
              step="01"
              title="Upload image"
              description="Choose a clear fish image from your device."
            />

            <StepCard
              step="02"
              title="AI prediction"
              description="The model predicts fish species and confidence score."
            />

            <StepCard
              step="03"
              title="View information"
              description="Open full details for general, farmer, and ornamental care."
            />
          </div>
        </section>
      </div>
    </main>
  );
}

function QuickAction({
  href,
  title,
  description,
}: {
  href: string;
  title: string;
  description: string;
}) {
  return (
    <Link
      href={href}
      className="rounded-3xl bg-slate-50 p-5 transition hover:-translate-y-1 hover:bg-blue-50 hover:shadow-sm"
    >
      <h3 className="font-bold text-slate-900">{title}</h3>
      <p className="mt-2 text-sm leading-6 text-slate-500">{description}</p>
    </Link>
  );
}

function StepCard({
  step,
  title,
  description,
}: {
  step: string;
  title: string;
  description: string;
}) {
  return (
    <div className="rounded-3xl bg-slate-50 p-5">
      <p className="text-sm font-extrabold text-blue-600">{step}</p>
      <h3 className="mt-2 font-bold text-slate-900">{title}</h3>
      <p className="mt-2 text-sm leading-6 text-slate-500">{description}</p>
    </div>
  );
}